const express = require('express');
const morgan = require('morgan')
const mongoose = require('mongoose')
const blogRoutes = require('./routes/blogRoutes');
const dbURI= "mongodb+srv://netninja:Test1234@cluster0.l8cl3br.mongodb.net/Node_Tutorial?retryWrites=true&w=majority";

mongoose.connect(dbURI).then((result) => app.listen(3000))
    .catch((err) => console.log(err));
const app = express(); 

app.set('view engine', 'ejs');
app.set('views');


// middleware & static files
app.use(express.static('./public'));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));
app.use((req, res, next) => {
    res.locals.path = req.path;
    next();
  });

// routes without using conttroller
// app.get('/',(req,res)=>{
// // res.sendFile('./views/example.html',{root: __dirname});
// res.status(200).render('index',{title : "Home", blogs});
// });
// app.get('/about',(req,res)=>{
// // res.sendFile('./views/about.html',{root: __dirname});
//     res.status(200).render('about',{title : "About"});
// });
// app.get('/about-me',(req,res)=>{
//     res.redirect('/about');
// });
// app.get('/blogs/create',(req,res)=>{
//     res.status(200).render('create', {title : "Create  a Blog"});
// });
// app.use((req,res)=>{
//     // res.status(404).sendFile('./views/404.html',{root:__dirname});
//     res.status(404).render('404',{title : "404"});
// });


// routes using controller
app.get('/', (req, res) => {
  res.redirect('/blogs');
});

app.get('/about', (req, res) => {
  res.render('about', { title: 'About' });
});

// blog routes
app.use('/blogs', blogRoutes);

// 404 page
app.use((req, res) => {
  res.status(404).render('404', { title: '404' });
});